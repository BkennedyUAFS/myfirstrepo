#include <stdio.h>

int main(){

    int numbers[5] = {1, 2, 3, 4, 5};

    for (int i = 0; i < 5; i++) { 
        printf("element at %d: %d\n", i, numbers[i]);
    }

    char string[] = "Hello";

    for (int i = 0; string[i] != '\0'; i++) {
        printf("Character at index %d: %c\n", i, string[i]);
    }

}
