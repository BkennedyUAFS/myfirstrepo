#include <stdio.h>

showString(char *str);

int main(){
    char str[]="Hello";
    showString(str);
}

showString(char *str){
    while(*str!='\0'){
        putchar(*str);
        str++;
    }
    putchar('\n');
}