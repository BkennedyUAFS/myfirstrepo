#include <stdio.h>
#include <stdlib.h>

int main() { 
    int n = 5; 
    int *numbers = (int *)malloc(n * sizeof(int));

    for(int i = 0; i < n; i++) {
        numbers[i] = 10 + (i * 10);
    }

    printf("Array elements:\n");
    for(int i = 0; i < n; i++){
        printf("%d ", numbers[i]);
    }

    free(numbers);
    return 0; 
}