#include <stdio.h>

#define MAXLINE 1024

/**** Function Prototypes ****/
int getString(char str[], int max);
void putString(char str[]);
void copyString(char src[], char dst[]);
	
int main(int argc, char *args[]){

   return 0;
}

//**** Get String from Standard Input (stdin) *****
int getString(char str[], int max){


}

//***** Write String to Standard Output (stdout) *******
void putString(char str[]){


}

//***** Copy String *******
void copyString(char src[], char dst[]){


}
